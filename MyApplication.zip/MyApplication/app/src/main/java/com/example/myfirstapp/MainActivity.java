package com.example.myfirstapp;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.Gravity;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import static com.example.myfirstapp.R.id.contactView;
public class MainActivity extends AppCompatActivity
{
    public static String contactName;
    public static String contactNumber;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String displayName; //Contact Name Selected
        String id; //Contact Id Selected
        String number = null; //Phone Number


        android.widget.LinearLayout contactSpace = findViewById(contactView);
        Cursor messageCursor = getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC");

        while (messageCursor.moveToNext()) //Iterates through contacts
        {
            int phoneNumberSaved = Integer.parseInt(messageCursor.getString(messageCursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)));

            if (phoneNumberSaved > 0) //Determine if contact has a phone number
            {
                displayName = messageCursor.getString(messageCursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                id = messageCursor.getString(messageCursor.getColumnIndex(ContactsContract.Contacts._ID));


                ContentResolver contentResolver = getContentResolver();

                Cursor numberCursor = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + id, null, null);
                while (numberCursor.moveToNext())
                {
                    number = numberCursor.getString(numberCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    //numberType = phones.getInt(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE));
                }
                numberCursor.close();
                if (number != null)
                {
                    //Create button to select contact
                    Button selectContact = new Button(this);
                    selectContact.setBackgroundResource(R.drawable.select_message);
                    selectContact.setPadding(50, 50, 50, 50);
                    selectContact.setGravity(Gravity.START);
                    selectContact.setTextColor(getResources().getColor(R.color.dark_grey));


                    //Trims number
                    number = number.replaceAll("[^0-9.]", "");
                    if(number.length() >= 11)
                    {
                        number = number.substring(number.length() - 10);
                    }
                    String nameAndNumber = displayName + "\n" + number;
                    selectContact.setText(nameAndNumber);
                    selectContact.setContentDescription(nameAndNumber);

                    //Define button behavior
                    selectContact.setOnClickListener(selectContact1 ->
                    {

                        String Name = selectContact1.getContentDescription().toString();
                        String[] contactInfo = Name.split("\n", 25);

                        Intent intent = new Intent(MainActivity.this, DisplayMessageActivity.class);
                        intent.putExtra(contactName, contactInfo[0]);
                        intent.putExtra(contactNumber, contactInfo[1]);

                        startActivity(intent);

                    });

                    contactSpace.addView(selectContact);  //Add button to layout

                }



            }
        }
        messageCursor.close();

    }
}


package com.example.myfirstapp;

import static com.example.myfirstapp.R.id.messageView;
import static com.example.myfirstapp.R.id.wrap_content;

import android.Manifest;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log; //do not optimize this out untill DNE
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.spec.KeySpec;
import java.util.Base64;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.DialogFragment;
import java.security.spec.X509EncodedKeySpec;

public class DisplayMessageActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);
        Intent intent = getIntent();

        //Trims number retrieved from contacts
        String number = intent.getStringExtra(MainActivity.contactNumber);

        //Changes activity title to contact selected
        String name = intent.getStringExtra(MainActivity.contactName);
        setTitle(name);

        //Message Cursor
        ActivityCompat.requestPermissions(DisplayMessageActivity.this, new String[]{Manifest.permission.READ_SMS}, PackageManager.PERMISSION_GRANTED);
        Cursor messageCursor = getContentResolver().query(Uri.parse("content://sms"), null, null, null, null);
        messageCursor.moveToFirst();


        String body = messageCursor.getString(messageCursor.getColumnIndex("body")); //Message sent
        String address = null; //Phone number of other party

        String type;  //Indicates delivery status and whether incoming/outgoing
        LinearLayout messageSpace;
        messageSpace = findViewById(messageView);
        String key = null;

        messageCursor.moveToFirst();

        int i = 0;
        while (messageCursor.moveToNext() && i < 70) //Iterates through text messages, displays 70 from selected sender
        {

            address = messageCursor.getString(messageCursor.getColumnIndex("address"));
            if (address != null) //Prevents application from crashing when a draft is saved
            {

                body = messageCursor.getString(messageCursor.getColumnIndex("body"));

                address = address.replaceAll("[^0-9.]", ""); //trimming the phone number
                if(address.length() >= 11)
                {
                    address = address.substring(address.length() - 10);
                }

                if (address.equals(number))//Checks if message is from selected sender
                {
                    i = i + 1;

                    type = messageCursor.getString(messageCursor.getColumnIndex("type"));

                    TextView messageBubble = new TextView(this);

                    // TODO: implement decryption in AES 256

                    messageBubble.setTextColor(getResources().getColor(R.color.white));

                    messageBubble.setText(body);

                    messageBubble.setTop(0);
                    messageBubble.setPadding(30, 20, 30, 20);

                    messageBubble.setWidth(wrap_content);  //This doesn't seem to work

                    if (type.equals("1"))//Type is 1 if the message is incoming
                    {
                        messageBubble.setBackgroundResource(R.drawable.your_rectangle);
                    }
                    if (type.equals("2"))//Type is 2 if the message is outgoing
                    {
                        messageBubble.setBackgroundResource(R.drawable.my_rectangle);
                    }
                    // TODO: Create styles for other message types
                    if (body.indexOf("OpenSSLRSAPublicKey") == 0) //Check for encryption keys
                    {
                        key = body;
                    }

                    messageSpace.addView(messageBubble, 0);
                }
            }
        }
        messageSpace.requestLayout();

        messageCursor.close();

        //Deal with encryption keys
        if (key != null)
        {
            try
            {
                KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
                keyStore.load(null);
                final KeyStore.SecretKeyEntry secretKeyEntry = (KeyStore.SecretKeyEntry) keyStore.getEntry(address, null);

                final SecretKey secretKey = secretKeyEntry.getSecretKey();
            } catch (Exception e)
            {
                e.printStackTrace();
            }

        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) //The menu bar
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.display_message_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.encrypt:
                switch_to_encryption();
                return true;
            case R.id.settings:
                ///showHelp();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void requestEncryption() //Trade keys with previously unsecured number
    {

        try //Try generating private and public key
        {
            KeyPairGenerator keyGenerator;
            KeyPair secretKeys;
            keyGenerator = KeyPairGenerator.getInstance("RSA");
            keyGenerator.initialize(4096);

            secretKeys = keyGenerator.generateKeyPair();
            Key publicKey = secretKeys.getPublic();
            Key privateKey = secretKeys.getPrivate();
            SmsManager smsManager = SmsManager.getDefault();

            Intent intent = getIntent();
            String number = intent.getStringExtra(MainActivity.contactNumber);


            ActivityCompat.requestPermissions(DisplayMessageActivity.this, new String[]{Manifest.permission.READ_SMS}, PackageManager.PERMISSION_GRANTED);
            Cursor messageCursor = getContentResolver().query(Uri.parse("content://sms"), null, null, null, null);
            messageCursor.moveToFirst();
            String body = messageCursor.getString(messageCursor.getColumnIndex("body"));
            String lastdate = messageCursor.getString(messageCursor.getColumnIndex("date"));
            String date = lastdate;
            String type = messageCursor.getString(messageCursor.getColumnIndex("type"));



            String key = String.valueOf(publicKey);
            String keyPart = null;
            for (int i = 0; i < 8; i++) {
                keyPart = key.substring(140*i, Math.min(140*(i+1) - 1, key.length()));
                keyPart = "{" + i + " KEY REQUEST} " + keyPart;
                smsManager.sendTextMessage("+12899870816", null, keyPart, null, null);

            }

            while (!body.equals("{7 KEY REQUEST}") || Long.parseLong(date) <= Long.parseLong(lastdate))
            {
                if (!body.equals("{7 KEY REQUEST}"))
                {

                }
                if (Long.parseLong(date) <= Long.parseLong(lastdate))
                {

                }

                messageCursor = getContentResolver().query(Uri.parse("content://sms"), null, null, null, null);
                messageCursor.moveToFirst();

                body = messageCursor.getString(messageCursor.getColumnIndex("body"));
                date = messageCursor.getString(messageCursor.getColumnIndex("date"));

                body = body.substring(0, 15);
            }


            messageCursor = getContentResolver().query(Uri.parse("content://sms"), null, null, null, null);
            messageCursor.moveToFirst();

            int i = 0;
            String rsa = ""; //messageCursor.getString(messageCursor.getColumnIndex("body"));
            String keytwo = ""; //rsa.substring(15);
           // messageCursor.moveToNext();
            while (messageCursor.moveToNext() && i < 8) //Iterates through text messages
            {
                if (type.equals("1"))//Type is 1 if the message is incoming
                {
                    i = i + 1;
                    rsa = messageCursor.getString(messageCursor.getColumnIndex("body"));
                    keytwo = keytwo.concat(rsa); //.substring(16));

                }
            }
            messageCursor.close();
            if (key.equals(keytwo))
            {
            }


        }
        catch (Exception e)
        {
            e.printStackTrace();


        }
    }


    public void switch_to_encryption()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Request Encryption?");
        builder.setMessage("The other person must have this app installed.");

        builder.setPositiveButton("Okay", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                dialog.dismiss();

                requestEncryption();

            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {

                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();

        dialog.show();
    }


    //@android.support.annotation.RequiresApi(api = Build.VERSION_CODES.DONUT)
    public void sendMessage(View view) //Sending messages!
    {
        EditText messageInput = findViewById(R.id.messageInput);
        String message = messageInput.getText().toString();

        Intent intent = getIntent();
        String number = intent.getStringExtra(MainActivity.contactNumber); //keep this

        try
        {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("+12899870816", null, message, null, null);
        }
        catch (Exception e)
        {
        }

        KeyGenerator keyGenerator;

        SecretKey secretKey;
        try
        {
            keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(256);
            secretKey = keyGenerator.generateKey();
        }

        catch (Exception e)
        {
            e.printStackTrace();
        }
        byte[] IV = new byte[16];
        SecureRandom random;
        random = new SecureRandom();
        random.nextBytes(IV);

        messageInput.getText().clear();

    }

    public void decrypt(String string) //TODO: Decrypt incoming messages, if possible.
    {

    }


}

package com.example.myfirstapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import static com.example.myfirstapp.R.id.messageView;
import static com.example.myfirstapp.R.id.wrap_content;

public class DisplayMessageActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);
        Intent intent = getIntent();

        //Trims number retrieved from contacts
        String number = intent.getStringExtra(MainActivity.contactNumber);


        //Changes activity title to contact selected
        String name = intent.getStringExtra(MainActivity.contactName);
        setTitle(name);

        //Message Cursor
        ActivityCompat.requestPermissions(DisplayMessageActivity.this, new String[]{Manifest.permission.READ_SMS}, PackageManager.PERMISSION_GRANTED);
        Cursor messageCursor = getContentResolver().query(Uri.parse("content://sms"), null, null, null, null);
        //cursor.moveToFirst();

        int i = 0;

        String body;  //Message sent
        String address; //Phone number of other party
        String type;  //Indicates delivery status and whether incoming/outgoing


        while (messageCursor.moveToNext() && i < 10) //Iterates through text messages
        {
            i = i + 1;
            address = messageCursor.getString(messageCursor.getColumnIndex("address"));
            address = address.substring(2);

            //if (address.equals("+14168206502")) //Checks if message is from selected sender
            if (address.equals(number))//Checks if message is from selected sender
            {
                body = messageCursor.getString(messageCursor.getColumnIndex("body"));
                type = messageCursor.getString(messageCursor.getColumnIndex("type"));

                TextView messageBubble = new TextView(this);
                android.widget.LinearLayout messageSpace;
                messageSpace = findViewById(messageView);

                // TODO: implement decryption in AES 256
                messageBubble.setText(body);

                messageBubble.setBottom(0);
                messageBubble.setPadding(30, 20, 30, 20);

                messageBubble.setWidth(wrap_content);  //This doesn't seem to work

                if (type.equals("1"))//Type is 1 if message is incoming
                {
                    messageBubble.setBackgroundResource(R.drawable.your_rectangle);
                }
                if (type.equals("2"))//Type is 2 if message is outgoing
                {
                    messageBubble.setBackgroundResource(R.drawable.my_rectangle);
                }
                // TODO: Create styles for other message types
                messageSpace.addView(messageBubble);

            }
        }
        messageCursor.close();
    }

}
